---
name: Feature request
about: Suggest a feature or enhancement
---

<!-- ⚠️ Please search existing issues to avoid creating duplicates. ⚠️ -->
<!-- Describe the enhancement here. -->
