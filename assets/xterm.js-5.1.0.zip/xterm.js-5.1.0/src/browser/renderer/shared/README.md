This folder contains files that are shared between the renderer addons, but not necessarily bundled into the `xterm` module.
