/**
 * Copyright (c) 2022 The xterm.js authors. All rights reserved.
 * @license MIT
 */

export interface ILigatureOptions {
  fallbackLigatures: string[];
}
